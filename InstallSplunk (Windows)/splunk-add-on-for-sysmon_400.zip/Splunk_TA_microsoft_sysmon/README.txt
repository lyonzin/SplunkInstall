Splunk Add-on for Sysmon version 1.0.0
Copyright (C) 2021 Splunk Inc. All Rights Reserved.

For documentation, see: https://docs.splunk.com/Documentation/AddOns/latest/MSSysmon
